    <input
              onClick={() => {}}
              placeholder="${url(./public/Icon-Google.png)}Sign Up  With Google"
            />